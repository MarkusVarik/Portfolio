Cypher Tool

Overview

The Cypher Tool is designed to encrypt and decrypt messages using simple
ciphers. The tool currently supports the following ciphers:

1. ROT13: A cipher tool that replaces each letter with the 13th letter
after it in the alphabet

2. Reverse: A simple cipher that reverses the order of characters in the
message

3. SwapCase: Converts lowercase letter to uppercase letters and vice versa

Usage

How do use the Cyper Tool

1. Run the program from the command line.

2. Select the operation:

	'1' to encrypt a message
	
	'2' to decrypt a message

3. Select the encoding method:

	'1' for ROT13
	
	'2' for Reverse

	'3' for Swapcase

4. Enter the message you wish to encrypt or decrypt


Ciphers

ROT13:

ROT13 is a simple letter substitution cipher that replaces a letter
with the 13th letter after it in the Latin alphabet.

	Encryption example:

		Input: 'Kood/Jõhvi'
		
		Output: 'Xbbq/Wõuiv'

	Decryption example:

		Input: 'Xbbq/Wõuiv'

		Output: 'Kood/Jõhvi'


Reverse

The reverse cipher method reverses the order of characters in the string.

	Encryption example:

		Input: 'Kood/Jõhvi'

		Output: 'ivhõJ/dooK'


	Decryption example:

		Input 'ivhõJ/dooK'

		Output 'Kood/Jõhvi'

Swapcase

The swapcase cipher converts lowercase letters to uppercase letters and vice versa

	Encryption example:

		Input: 'kood/johvi'

		Output: 'KOOD/JOHVI'

	Decryption example:

		Input: 'KOOD/JOHVI'

		Output: 'kood/johvi'




