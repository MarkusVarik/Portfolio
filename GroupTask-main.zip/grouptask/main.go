package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func main() {
	fmt.Printf("Welcome to the Cypher Tool\n")

	toEncrypt, encoding, message := getInput()

	var result string
	if toEncrypt {
		switch encoding {
		case "1":
			result = encrypt_rot13(message)
		case "2":
			result = encrypt_reverse(message)
		case "3":
			result = encryptswapcase(message)
		}
	} else {
		switch encoding {
		case "1":
			result = decrypt_rot13(message)
		case "2":
			result = decrypt_reverse(message)
		case "3":
			result = decrypt_swapcase(message)

		}
	}

	fmt.Println(result)

}

// Getting User input

func getInput() (toEncrypt bool, encoding string, message string) {
	var eord string
	var Cypher string
	reader := bufio.NewReader(os.Stdin)

	// select operation : Encrypt or Decrypt

	for {
		fmt.Print("Select Operation by entering 1 or 2\n1. Encrypt\n2. Decrypt\n")
		eord, _ = reader.ReadString('\n')
		eord = strings.TrimSpace(eord)

		if eord == "1" || eord == "2" {
			toEncrypt = (eord == "1")
			break
		}
		fmt.Println("Invalid operation. Please try again.")
	}

	// Select cypher type
	for {
		fmt.Print("Select Cypher by entering 1, 2 or 3\n1. ROT13\n2. Reverse\n3. Swapcase\n")
		Cypher, _ = reader.ReadString('\n')
		Cypher = strings.TrimSpace(Cypher)
		if Cypher == "1" || Cypher == "2" || Cypher == "3" {
			encoding = Cypher
			break
		}
		fmt.Println("Invalid cypher type. Please try again.")
	}

	// Input message to encrypt/decrypt
	fmt.Print("Enter the message: ")
	message, _ = reader.ReadString('\n')
	message = strings.TrimSpace(message)

	return toEncrypt, encoding, message
}

// cypher ROT13
func encrypt_rot13(s string) string {
	var encrypted strings.Builder
	for _, char := range s {
		if char >= 'A' && char <= 'Z' {
			encrypted.WriteRune((char-'A'+13)%26 + 'A')
		} else if char >= 'a' && char <= 'z' {
			encrypted.WriteRune((char-'a'+13)%26 + 'a')
		} else {
			encrypted.WriteRune(char)
		}
	}
	return encrypted.String()
}

// cypher Reverse
func encrypt_reverse(s string) string {
	var encrypted strings.Builder
	for _, char := range s {
		if char >= 'A' && char <= 'Z' {
			encrypted.WriteRune('Z' - (char - 'A'))
		} else if char >= 'a' && char <= 'z' {
			encrypted.WriteRune('z' - (char - 'a'))
		} else {
			encrypted.WriteRune(char)
		}
	}
	return encrypted.String()
}

// Cypher convert lower case alphabets to upper case
func encryptswapcase(s string) string {
	var result strings.Builder
	for _, char := range s {
		if char >= 'a' && char <= 'z' {
			result.WriteRune(char - 32)
		} else if char >= 'A' && char <= 'Z' {
			result.WriteRune(char + 32)
		} else {
			result.WriteRune(char)
		}
	}
	return result.String()
}

// Decrypt for all the cyphers are their inveserses
// Decrypt rot13
func decrypt_rot13(s string) string {

	return encrypt_rot13(s)
}

// Decrypt reverse
func decrypt_reverse(s string) string {
	return encrypt_reverse(s)
}

// Decrypt
func decrypt_swapcase(s string) string {
	return encryptswapcase(s)
}
