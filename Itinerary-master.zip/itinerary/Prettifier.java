import java.io.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.function.*;
import java.util.regex.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Prettifier {

    // Display usage instructions
    public static void displayUsage() {
        System.out.println("Usage: java Prettifier <input file> <output file> <airport lookup file>");
    }

    // Parse the airport lookup file, supporting dynamic column order
    public static Map<String, String> parseAirportLookupFile(String airportLookupFile) {
        Map<String, String> airportMap = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(airportLookupFile))) {
            String header = reader.readLine();
            if (header == null) {
                throw new IOException("Empty airport lookup file.");
            }

            String[] columns = header.split(",");
            int nameIndex = -1, icaoIndex = -1, iataIndex = -1, cityIndex = -1;

            for (int i = 0; i < columns.length; i++) {
                switch (columns[i].trim().toLowerCase()) {
                    case "name": nameIndex = i; break;
                    case "icao_code": icaoIndex = i; break;
                    case "iata_code": iataIndex = i; break;
                    case "municipality": cityIndex = i; break;
                }
            }

            if (nameIndex == -1 || (icaoIndex == -1 && iataIndex == -1)) {
                System.out.println("Airport lookup malformed");
                return null;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Reading line: " + line); // Debugging: Log each line read
                String[] data = splitCsvLine(line);
                if (data.length <= Math.max(nameIndex, Math.max(icaoIndex, iataIndex))) {
                    System.out.println("Malformed airport lookup row: " + line);
                    continue;
                }

                String name = data[nameIndex].trim();
                if (icaoIndex != -1) airportMap.put(data[icaoIndex].trim(), name);
                if (iataIndex != -1) airportMap.put(data[iataIndex].trim(), name);

                if (cityIndex != -1) {
                    airportMap.put("*" + data[icaoIndex].trim(), data[cityIndex].trim());
                    airportMap.put("*" + data[iataIndex].trim(), data[cityIndex].trim());
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading airport lookup file: " + e.getMessage());
            return null;
        }
        return airportMap;
    }

    // Split CSV line manually, handling quotes
    public static String[] splitCsvLine(String line) {
        List<String> columns = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean insideQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == ',' && !insideQuotes) {
                columns.add(currentField.toString().trim());
                currentField.setLength(0);
            } else if (c == '"') {
                insideQuotes = !insideQuotes;
            } else {
                currentField.append(c);
            }
        }
        columns.add(currentField.toString().trim());
        return columns.toArray(new String[0]);
    }

    // Process each line of the input file
    public static String processLine(String line, Map<String, String> airportLookup) {
        System.out.println("Processing line: " + line); // Debugging: Log the line being processed

        // Replace IATA/ICAO and city names
        for (Map.Entry<String, String> entry : airportLookup.entrySet()) {
            String code = entry.getKey();
            String name = entry.getValue();
            if (line.contains(code)) {
                line = line.replace(code, name);
            }
        }

        // Format dates and times
        line = reformatTimestamps(line);

        // Replace vertical whitespace characters with newlines
        line = line.replaceAll("[\\v\\f\\r]", "\n");

        // Trim excessive blank lines
        line = line.replaceAll("(?<=\\n)\\n+", "\n");

        // Apply additional formatting
        line = applyFormatting(line);

        System.out.println("Formatted line: " + line); // Debugging: Log the formatted line
        return line;
    }

    // Reformat timestamps (dates and times)
    public static String reformatTimestamps(String line) {
        // Reformat dates (D)
        line = replaceWithPattern(line, "D\\(([^)]+)\\)", match -> {
            try {
                OffsetDateTime dateTime = OffsetDateTime.parse(match);
                return dateTime.format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
            } catch (DateTimeParseException e) {
                return "D(" + match + ")"; // Leave unchanged if parsing fails
            }
        });

        // Reformat 12-hour times (T12)
        line = replaceWithPattern(line, "T12\\(([^)]+)\\)", match -> {
            try {
                OffsetDateTime dateTime = OffsetDateTime.parse(match);
                return dateTime.format(DateTimeFormatter.ofPattern("hh:mma (xxxxx)")).replace("AM", "am").replace("PM", "pm");
            } catch (DateTimeParseException e) {
                return "T12(" + match + ")"; // Leave unchanged if parsing fails
            }
        });

        // Reformat 24-hour times (T24)
        line = replaceWithPattern(line, "T24\\(([^)]+)\\)", match -> {
            try {
                OffsetDateTime dateTime = OffsetDateTime.parse(match);
                return dateTime.format(DateTimeFormatter.ofPattern("HH:mm (xxxxx)"));
            } catch (DateTimeParseException e) {
                return "T24(" + match + ")"; // Leave unchanged if parsing fails
            }
        });

        return line;
    }

    // Helper method for regex-based replacements
    public static String replaceWithPattern(String input, String regex, Function<String, String> replacer) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        StringBuffer result = new StringBuffer();

        while (matcher.find()) {
            String match = matcher.group(1); // Capture the first group
            matcher.appendReplacement(result, Matcher.quoteReplacement(replacer.apply(match)));
        }

        matcher.appendTail(result);
        return result.toString();
    }

    // Apply formatting to the text
    public static String applyFormatting(String line) {
        line = line.replaceAll("\\b(\\d{2} \\w{3} \\d{4})\\b", "\033[1;34m$1\033[0m"); // Highlight dates in blue
        line = line.replaceAll("\\b(\\d{2}:\\d{2}(am|pm|))\\b", "\033[1;32m$1\033[0m"); // Highlight times in green
        line = line.replaceAll("(\\([-+0-9:Z]+\\))", "\033[1;35m$1\033[0m"); // Highlight offsets in magenta
        return line;
    }

    // Process the entire file
    public static void processItineraryFile(String inputFile, String outputFile, String airportLookupFile) {
    try {
        // Parse the airport lookup file
        Map<String, String> airportLookup = parseAirportLookupFile(airportLookupFile);
        if (airportLookup == null) {
            System.out.println("Airport lookup malformed");
            return;
        }

        // Read all lines from the input file
        List<String> lines = Files.readAllLines(Paths.get(inputFile));
        StringBuilder processedContent = new StringBuilder();

        // Process each line
        for (String line : lines) {
            String processedLine = processLine(line, airportLookup);
            processedContent.append(processedLine).append("\n");
            System.out.println("Processed Line: " + processedLine); // Debugging: Log processed line
        }

        // Write the processed content to the output file
        System.out.println("Writing processed content to: " + outputFile);
        System.out.println("Content to write:\n" + processedContent.toString());
        Files.write(Paths.get(outputFile), processedContent.toString().getBytes());
        System.out.println("File writing complete.");
    } catch (IOException e) {
        System.out.println("Error processing files: " + e.getMessage());
    }
}

    // Main method
    public static void main(String[] args) {
        if (args.length == 1 && args[0].equals("-h")) {
            displayUsage();
            return;
        }

        if (args.length < 3) {
            displayUsage();
            return;
        }

        processItineraryFile(args[0], args[1], args[2]);
    }
}
