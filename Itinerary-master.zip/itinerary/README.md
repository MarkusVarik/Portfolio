# Itinerary Prettifier

## Overview

`itinerary-prettifier` is a command-line tool that transforms raw flight itineraries into a polished, customer-friendly format. It converts airport codes to full names, formats dates and times, and trims unnecessary whitespace.

This tool was created for Anywhere Holidays, an online travel agency, to reduce the time administrators spend manually editing itineraries.

## Features

- Airport Code Conversion: Replaces IATA (`#LAX`) and ICAO (`##EGLL`) codes with full airport names or cities.
- Date & Time Formatting:
- Converts ISO 8601 dates (`D2024-03-15`) to human-readable formats (`15-Mar-2024`).
- Supports 12-hour (`10:30am`) and 24-hour times (`10:30+02:00`).
- Whitespace Management: Removes excessive blank lines.
- Error Handling: Provides clear error messages for missing or malformed data.
- Dynamic CSV Parsing: Processes airport lookup tables in flexible formats.

## Usage

Run the tool from the command line:

java Prettifier.java <input.txt> <output.txt> <airport-lookup.csv>

## Arguments
1. `<input.txt>`: Path to the raw flight itinerary file.
2. `<output.txt>`: Path to save the prettified output file.
3. `<airport-lookup.csv>`: CSV file with airport codes and their full names.

## Input Format

1. Airport Codes:
    - IATA codes prefixed with `#` (`e.g., #LAX`).
    - ICAO codes prefixed with `##` (`e.g., ##EGLL`).
2. Dates & Times:
    - Dates prefixed with `D` (e.g., `D2024-03-15T10:30+02:00`).
    - 12-hour times prefixed with `T12` and 24-hour times with `T24`.
- Whitespace: Consecutive blank lines are removed.
## Output Format

The prettified file includes:

1. Readable Dates: `D2024-03-15T10:30+02:00` → `15-Mar-2024`
2. Readable Times: `T122024-03-15T10:30` → `10:30am (+0200)`
3. Airport Names: `#LAX` → `Los Angeles International Airport`